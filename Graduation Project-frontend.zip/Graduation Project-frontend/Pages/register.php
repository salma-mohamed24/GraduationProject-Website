<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $nationalId = $_POST["nationalid"];
    $plateNumber = $_POST["plate"];
    $phoneNumber = $_POST["number"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["password2"];

    // Validate form data (you can add more validation as per your requirements)
    $errors = [];

    if (empty($username)) {
        $errors[] = "Username is required.";
    }

    if (empty($nationalId)) {
        $errors[] = "National ID is required.";
    }

    if (empty($plateNumber)) {
        $errors[] = "Plate number is required.";
    }

    if (empty($phoneNumber)) {
        $errors[] = "Phone number is required.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // If there are no errors, process the form data
    if (empty($errors)) {
        // Perform further actions like storing the data in a database or sending it via email
        // ...
        
        // Redirect the user to a success page
        header("Location: success.html");
        exit;
    }
}
?>

